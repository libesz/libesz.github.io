
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include <stdlib.h>
#include <avr/eeprom.h>
#include "usart.h"

void init( void );
void send_rec_dump( void );

// global variables for recieving IR data
volatile unsigned int ptemp=0, buf_index=0, buffer[200];
volatile unsigned char got=0;
#define MAXTIME 2000

ISR(USART_RXC_vect)
{
   unsigned char rec_byte=UDR;
   cli();
   if( rec_byte == '\r' )
   {

      usart_puti(ptemp);
      usart_putc(' ');

      usart_nl();
   }
   else
   {
      usart_putc(rec_byte);
   }
   sei();
}

// timer overflow for more proper time measure
ISR (TIMER0_OVF_vect)
{
   if( ptemp < MAXTIME ) ptemp++;
   else if( !got && buf_index ) got=1;
}

// interrupt pin to got the data
ISR (INT0_vect)
{
   if( ptemp != MAXTIME )
   {
      buffer[buf_index] = ptemp;
      buf_index++;
   }
   else got = 0;

   ptemp=0;
}

int main( void )
{
   init();
   sei();

   usart_nl();
   usart_puts_P("  ___started up___");
   usart_nl();

   while(1)
   {
      if( got )
      {
         usart_puti( buf_index );
         usart_puts_P(" : ");
         for( unsigned char i=0; i<buf_index; i++)
         {
            usart_puti( buffer[i] );
            buffer[i] = 0;
            usart_putc(' ');
         }
         usart_nl();
         got = 0;
         buf_index = 0;
      }
   }
}

void init( void )
{
   TCCR0  =0b00000001;
   TIMSK |= 1<<TOIE0; //timer 0 overflow on

   usart_init();

   GIMSK |= (1<<INT0);
   MCUCR |= ((1<<ISC01) | (0<<ISC00));
}

