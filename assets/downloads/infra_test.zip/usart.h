#ifndef UART_H
#define UART_H

#define USART_BAUDRATE 38400
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)
#define usart_puts_P(__s) usart_puts_p(P(__s))
#define P(s) ({static const char c[] __attribute__ ((progmem)) = s;c;})


extern void usart_init( void );

extern void usart_putc( unsigned char c );

extern void usart_puts ( unsigned char *s);

extern void usart_nl( void );

extern void usart_puts_p(const char *progmem_s );

extern void usart_puti( const int val );

extern void usart_put_prompt( void );

#endif // UART_H 
