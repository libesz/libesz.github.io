//#define DEBUG
#include <avr\io.h>
#include <avr\interrupt.h>
#include <util\delay.h>
#include <compat/deprecated.h>
#include <compat/ina90.h>
#include <avr/pgmspace.h>

#ifdef DEBUG
#define USART_BAUDRATE 9600
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)
#define usart_puts_P(__s) usart_puts_p(P(__s))
#define P(s) ({static const char c[] __attribute__ ((progmem)) = s;c;})

void usart_init( void );
void usart_putc( unsigned char );
void usart_puts( unsigned char * );
void usart_puts_p(const char * );
void usart_puti( const int );
void usart_nl( void );
#endif

volatile unsigned char bright[3] = {0,0,0}; //initial brightness

volatile unsigned char soft_pwm_var = 0; //pwm signal loop variables
volatile unsigned int speed=30, speed_var = 0, idle=0; //define the change speed

volatile unsigned char actual_target=0;
volatile static unsigned char targets[9][3] = 
{
//   R   G   B
   {255,  0,  0},  //red
   {  0,255,  0},  //green
   {  0,  0,120},  //blue (the blue is much brighter than the others)
   {  0,255,120},  //kind of cyan and so on..
   {255,255,  0},
   {255,  0,120},
   {128,255,  0},
   {  0,128,120},
   {  0,  0, 60}
};

/*
PORTB 0,1,2 --> led1 red,green,blue
PORTB 3,4,5 --> led2 red,green,blue
*/

ISR (TIMER0_OVF_vect)
{
   speed_var++;
   if( speed_var == speed * 100 ) //changing the color components to get closer to the target
   {
      speed_var=0;
      if(!idle) //if we are not reached the target yet
      {
         for( unsigned char i=0 ; i<3 ; i++ )
         {
            if(bright[i]<targets[actual_target][i]) bright[i]++;  //if the component is lower than the target, it increases a little
            else if(bright[i]>targets[actual_target][i]) bright[i]--; //if not, decrement
         }
      }
      else //if we have already reached the target, wait some time before going to the next, to enjoy that color :)
      {
         idle++;
         if(idle==100)
         {
            idle=0;
#ifdef DEBUG
            usart_puts_P("idle end\r\n");
#endif
         }
      }
      if( bright[0] == targets[actual_target][0] && bright[1] == targets[actual_target][1] && bright[2] == targets[actual_target][2] ) //determining if the target has just reached
      {
#ifdef DEBUG
         usart_puts_P("target ");
         usart_puti(actual_target);
         usart_puts_P(" reached\r\n");
#endif
         if( ++actual_target == 9 ) actual_target=0; //when this is the end of the array, go to the first
         idle=1; //and set the idle timer on
      }
   }
   //this is the variable to compare with the brightness levels
   soft_pwm_var++;
   if(soft_pwm_var == 0) PORTB = 0b00111111; //set on all, when the pwm variable is overflowing
   for( unsigned char i=0 ; i<3 ; i++ ) //the core of the soft PWM
   {
      if(soft_pwm_var == bright[i]) PORTB &= ~((1<<i) | (1<<(i+3))); //set off both LED's color component based on it's brightness level
   }
}

int main(void)
{
   DDRB = 0b00111111;
   TCCR0 = 0b00000001;
   TIMSK |= 1<<TOIE0; //timer 0 overflow enabled
#ifdef DEBUG
   usart_init();
#endif

   sei();
   while(1)
   {
      //do nothing :) all the logic is in the timer overflow
   }
} 
#ifdef DEBUG

void usart_init( void )
{
   UCSRB |= (1 << RXEN) | (1 << TXEN);
   UCSRC |= (1 << URSEL) | (1 << UCSZ0) | (1 << UCSZ1);

   UBRRL = BAUD_PRESCALE;
   UBRRH = (BAUD_PRESCALE >> 8);
   UCSRB |= (1 << RXCIE);
}

void usart_putc( unsigned char c )
{
      while ((UCSRA & (1 << UDRE)) == 0);
      UDR = c;
}

void usart_puts ( unsigned char *s)
{
   while (*s)
   {
      usart_putc(*s);
      s++;
   }
}

void usart_nl( void )
{
   usart_puts_P("\r\n");
}

void usart_puts_p(const char *progmem_s )
{
    register char c;
    
    while ( (c = pgm_read_byte(progmem_s++)) ) 
      usart_putc(c);

}

void usart_puti( const int val )
{
    char buffer[sizeof(int)*8+1];
    
    usart_puts( itoa(val, buffer, 10) );

}

#endif
