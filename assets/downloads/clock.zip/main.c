#include <compat/deprecated.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint.h>
#include <util/delay.h>
#include <util/twi.h>
#include <avr/pgmspace.h> 

#define CATHODE_0_ON (sbi(PORTD,7))
#define CATHODE_0_OFF (cbi(PORTD,7))
#define CATHODE_1_ON (sbi(PORTD,6))
#define CATHODE_1_OFF (cbi(PORTD,6))
#define COLON_ON (sbi(PORTD,0))
#define COLON_OFF (cbi(PORTD,0))

////////// i2c read and write command in readable format
#define READ 1
#define WRITE 0

unsigned char bcd2bin(unsigned char);
unsigned char bin2bcd(unsigned char);

void i2c_init(void);
unsigned char i2c_start(unsigned char address);
void i2c_start_wait(unsigned char address);
unsigned char i2c_rep_start(unsigned char address);
void i2c_stop(void);
unsigned char i2c_write( unsigned char data );
unsigned char i2c_readAck(void);
unsigned char i2c_readNak(void);

volatile unsigned char button_pressed=0,timer_0_i=0,timer_2_i=0,active_cathode=0,temp_digit=0;
volatile unsigned char time[4]={16,16,16,16},can_change=0,min_plus=0,hour_plus;
volatile unsigned char temp_time[4]={16,16,16,16},anim=0;

volatile unsigned char segments[28]=
{
   0b00011000, //first digit's A segment, ID: 0.
   0b00010001, //first digit's B segment, ID: 1.
   0b00101001, //2
   0b00100000, //3
   0b00100001, //4
   0b00000000, //5
   0b00011001, //6
   0b00010011, //second digit's A segment, ID: 7. and so on..
   0b00000011, //8
   0b00001011, //9
   0b00001010, //10
   0b00101000, //11
   0b00010010, //12
   0b00000010, //13
   0b00011010, //14
   0b00000000, //15
   0b00101100, //16
   0b00101101, //17
   0b00111001, //18
   0b00011011, //19
   0b00000001, //20
   0b00001101, //21
   0b00110001, //22
   0b00100101, //23
   0b00100100, //24
   0b00111000, //25
   0b00001100, //26
   0b00110000  //27
};

volatile unsigned char number_look[17]=
{
   0b0111111,   //0
   0b0000110,   //1
   0b1011011,   //2
   0b1001111,   //3
   0b1100110,   //4
   0b1101101,   //5
   0b1111101,   //6
   0b0000111,   //7
   0b1111111,   //8
   0b1101111,   //9
   0b1110111,   //a
   0b1111100,   //b
   0b0111001,   //c
   0b1011110,   //d
   0b1111001,   //e
   0b1110001,   //f
   0b0000000    //empty
};

volatile unsigned char anim1[10]=
{
   0b0000001,
   0b0100011,
   0b1100011,
   0b1110111,
   0b1111111
};

ISR (TIMER0_OVF_vect)
{
   timer_0_i++;
   if(timer_0_i==10)
   {
      TIMSK &= ~(1<<TOIE0);
      button_pressed=0;
      timer_0_i=0;
   }
}

ISR (TIMER2_OVF_vect)
{
   unsigned char i=0,temp_segment=0,temp_number_look;

   PORTB=0;   //every anode and cathode off
   PORTC=0;
   PORTD&=0b00000001; //mind the colon only

   if(active_cathode==0)
   {
      active_cathode=1;
      CATHODE_1_ON;         //switching to the other cathode
   }
   else
   {
      active_cathode=0;
      CATHODE_0_ON;
   }

   while(temp_digit<4) //which digit we are dealing with (0-3)
   {
      while(i<7) //which segment of the digit (o-6 for a-g segments)
      {
         if(!(time[temp_digit] >= 0) || !(time[temp_digit] <=17))
         {
            temp_number_look=number_look[16];            //if we got wrong number somehow
         }
         else
         {
            temp_number_look=number_look[temp_time[temp_digit]]; //get the outlook of the number
         }

         if(anim && anim<50) //fun part, when minute is changing, it shows an animation, by manipulating the original look of the digit
         {
            temp_number_look |= anim1[anim/10];
         }
         else if(anim && anim<100)
         {
            temp_number_look = ~anim1[(anim-50)/10];
         }
         else if(anim && anim<130)
         {
            temp_number_look = number_look[16];
         }

         if(temp_number_look & (1<<i))   //we masking out the segment from the number_look, then we got that: has it to be turned on or not (oh, what a sentence )
         {
            temp_segment=segments[(temp_digit*7)+(i)]; //selecting the segment from the segments array
            if((temp_segment & 1) == active_cathode)     //we masking out the last bit, which shows the segment's cathode
            {
               temp_segment>>=1;                    //shifting out that bit
               switch(temp_segment%4)               //mask the next two bit is for the PORT selection
               {
                  case 0:
                     sbi(PORTB,temp_segment>>2);   //the rest 3 valid bit is the pin number
                     break;
                  case 1:
                     sbi(PORTC,temp_segment>>2);
                     break;
                  case 2:
                     sbi(PORTD,temp_segment>>2);
                     break;
               }
            }
         }
         i++; //next segment please
      }
      i=0;    //let's go to the first segment of the next digit
      temp_digit++;
   }

   temp_digit=0;  //go back to the first digit

   if(anim) //increase the animation counter, if it's already on
   {
      anim++;
   }
   if(temp_time[3]!=time[3] && !anim && !button_pressed) //start the animation if it is currently off AND the minute has changed AND it is not because we adjusting the time right now
   {
      anim=1;
   }

   if(anim==130) anim=0; //and of the animatio; above you can see what is the meaning of this counter

   if(!anim)
   {
      for(unsigned char i=0;i<4;i++) temp_time[i]=time[i]; //if we are not in animation, we store the time for the next comparison
   }
}

//handling button presses
ISR(INT0_vect)
{
   if(!button_pressed)
   {
      button_pressed=1;
      TCNT0=0;
      TIMSK |= 1<<TOIE0; //timer 0 overflow on
      min_plus=1;
   }
}

ISR(INT1_vect)
{
   if(!button_pressed)
   {
      button_pressed=1;
      TCNT0=0;
      TIMSK |= 1<<TOIE0; //timer 0 overflow on
      hour_plus=1;
   }
}

int main(void)
{
   unsigned char numtemp=0;
   TCCR0  =0b00000101;
   TCCR2  =0b00000101;
   TIMSK |= 1<<TOIE2;   //timer 2 overflow on

   sbi(MCUCR,0);     //INT0 pin is sensitive for edges
   sbi(GICR,6);      //enabling INT0 pin to ExtInt
   
   sbi(MCUCR,2);     //also INT1
   sbi(GICR,7);
   
   sei();
   
//port directions
   DDRD=0b11110011;
   DDRC=0b11001111;
   DDRB=0b11111111;

   i2c_init();

   i2c_start_wait(0xd0 | WRITE); //addressing the RTC with 0xd0 device code and the WRITE command
   i2c_write(0);
   i2c_stop();

   i2c_start_wait(0xd0 | READ);
   numtemp=i2c_readNak(); // read one byte and no nore
   i2c_stop();
   
   numtemp &= ~(1<<7);   //reset the sedonds' register's first bit to 0 (set 24h mode)

   _delay_ms(100);
   i2c_start_wait(0xd0 | WRITE);
   i2c_write(0);
   i2c_write(numtemp);
   i2c_stop();

   for(unsigned char i=0;i<4;i++) temp_time[i]=time[i];

   while(1)
   {

      if(min_plus) //when adjusting the minute
      {
         if(!i2c_start(0xd0 | WRITE)) // call the RTC
         {
            i2c_write(1); //minutes address is the '1'

            i2c_start(0xd0 | READ); //read it out
            numtemp=i2c_readNak(); // read one byte and no nore
            i2c_stop();
   
            numtemp=bcd2bin(numtemp); //converting to bin
            numtemp++;                //increasing the minute
            if(numtemp==60) numtemp=0;//if it has reached the 60, go back to 0
            numtemp=bin2bcd(numtemp); //convert back

            i2c_start_wait(0xd0 | WRITE);
            i2c_write(1);
            i2c_write(numtemp);  //write it back to the RTC
            i2c_stop();
            min_plus=0;
         }
      }

      if(hour_plus)//adjusting the hours, same as the minutes
      {
         if(!i2c_start(0xd0 | WRITE))
         {
            i2c_write(2);

            i2c_start(0xd0 | READ);
            numtemp=i2c_readNak();
            i2c_stop();
   
            numtemp=bcd2bin(numtemp);
            numtemp++;
            if(numtemp==24) numtemp=0;
            numtemp=bin2bcd(numtemp);

            i2c_start_wait(0xd0 | WRITE);
            i2c_write(2);
            i2c_write(numtemp);
            i2c_stop();
            hour_plus=0;
         }
      }

      if(!i2c_start(0xd0 | WRITE)) //normal operation, reading out the time...
      {
         i2c_write(0);
         i2c_stop();
         i2c_start(0xd0 | READ);
         numtemp=i2c_readAck(); // read the second, and keep going with Ack function
         if(numtemp%2)COLON_OFF;//it is just used to blink the colon
         else COLON_ON;
         numtemp=i2c_readAck(); // minutes coming
         time[2]=bcd2bin(numtemp)/10;
         time[3]=bcd2bin(numtemp)%10;
         numtemp=i2c_readNak(); // hours... and no more
         if(numtemp>>4 == 0) time[0]=16;
         else time[0]=bcd2bin(numtemp)/10;
         time[1]=bcd2bin(numtemp)%10;

         _delay_ms(100); //some break...

         i2c_stop();
      }
   }
}

////////// converts a bcd number to binary
unsigned char bcd2bin(unsigned char bcd)
{
   unsigned char bin=0;
   bcd&=~(1<<7);
   bin+=bcd&0x0f;
   bcd>>=4;
   bin+=bcd*10;
   return bin;
}

////////// converts a binary number to bcd
unsigned char bin2bcd(unsigned char bin)
{
   unsigned char bcd=0;
   bcd+=bin/10;
   bcd<<=4;
   bcd+=bin%10;
   return bcd;
}


void i2c_init(void)
{  
  TWSR = 0;
  TWBR = 32;
}// i2c_init

////////// start i2c operation, parameter is the slave's address or'ed with the READ or WRITE command in the LSB bit
////////// returns with 0-val if the device was unreachable, 1 if OK
unsigned char i2c_start(unsigned char address)
{
    unsigned char   twst;

   // start signal
   TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN);

   // wait for the end of the transmission
   while(!(TWCR & (1<<TWINT)));

   // analysing TWI status register (exept the prescaler bits), in case of error, return back with 1
   twst = TW_STATUS & 0xF8;
   if ( (twst != TW_START) && (twst != TW_REP_START)) return 1;

   // sending slave's address
   TWDR = address;
   TWCR = (1<<TWINT) | (1<<TWEN);

   // waiting for the end of transmission, recieving ACK or NACK
   while(!(TWCR & (1<<TWINT)));

   // TWI status regiszter vizsg�lata, el�oszt� bitek kimaszkolva
   twst = TW_STATUS & 0xF8;
   // analysing TWI status register (exept the prescaler bits), in case of unreachable slave device, return back with 1
   if ( (twst != TW_MT_SLA_ACK) && (twst != TW_MR_SLA_ACK) ) return 1;
   
   // return with 0
   return 0;

}// i2c_start


////////// start i2c operation with blocking, parameter is the slave's address or'ed with the READ or WRITE command in the LSB bit
void i2c_start_wait(unsigned char address)
{
    unsigned char   twst;

   //infinite loop
    while ( 1 )
    {
      // start signal
       TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN);
    
      // wait for the end of the transmission
       while(!(TWCR & (1<<TWINT)));
    
      // analysing TWI status register (exept the prescaler bits), in case of error, return back with 1
       twst = TW_STATUS & 0xF8;
       if ( (twst != TW_START) && (twst != TW_REP_START)) continue;
    
      // sending slave's address
       TWDR = address;
       TWCR = (1<<TWINT) | (1<<TWEN);
    
      // waiting for the end of transmission, recieving ACK or NACK
       while(!(TWCR & (1<<TWINT)));
    
      // analysing TWI status register (exept the prescaler bits)
       twst = TW_STATUS & 0xF8;
       if ( (twst == TW_MT_SLA_NACK )||(twst ==TW_MR_DATA_NACK) ) 
       {           
         // if device is busy, send stop signal
           TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWSTO);
           
         // waiting for the end of transmission
           while(TWCR & (1<<TWSTO));
           
           continue;
       }
       // else: break and return
       break;
     }

}// i2c_start_wait


////////// send i2c stop signal
void i2c_stop(void)
{
   TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWSTO);
   
   // waiting for the end of transmission
   while(TWCR & (1<<TWSTO));

}// i2c_stop


////////// send one byte to i2c device
////////// parameter: the one bute data
////////// returns with 0 is success, 1 if not
unsigned char i2c_write( unsigned char data )
{   
    unsigned char   twst;
    
   // sending data
   TWDR = data;
   TWCR = (1<<TWINT) | (1<<TWEN);

   // waiting for the end of transmission
   while(!(TWCR & (1<<TWINT)));

   // analysing TWI status register (exept the prescaler bits)
   twst = TW_STATUS & 0xF8;
   if( twst != TW_MT_DATA_ACK) return 1;
   return 0;

}// i2c_write


////////// recieving one byte from i2c device, and indicate to recieve more
////////// returns with the data
unsigned char i2c_readAck(void)
{
   TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWEA);
   while(!(TWCR & (1<<TWINT)));    

    return TWDR;

}// i2c_readAck


////////// recieving one byte from i2c device, and indicate that this is the last we want to recieve
////////// returns with the data
unsigned char i2c_readNak(void)
{
   TWCR = (1<<TWINT) | (1<<TWEN);
   while(!(TWCR & (1<<TWINT)));
   
    return TWDR;

}// i2c_readNak

