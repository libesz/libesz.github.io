//readable port definitions
#define MATRIX_DDR DDRD
#define MATRIX_PORT PORTD
#define VERT_CLK 7
#define VERT_DATA 6
#define HOR_CLK 5
#define HOR_DATA 4

//to count the stored frames number, then you don't have to define it
#define NUM_ELEM(x) (sizeof (x) / sizeof (*(x)))

//includes
#include <compat/deprecated.h>
#include <avr/io.h>
#include <stdint.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <avr/pgmspace.h>

void loadframe( unsigned char );

//the frames are stored in the program memory directly, because mega8 has only 1kB of RAM and it is not so much
const volatile unsigned int framepgm[][8] PROGMEM=
{
   {0x140,0x0,0x820,0x43c1,0x43c1,0x820,0x0,0x140},
   {0x50,0x0,0x4200,0x43e0,0xbc1,0x81,0x0,0x500},
   {0x14,0x4000,0x4080,0xbc0,0x3e0,0x201,0x1,0x1400},
   {0x4005,0x4000,0x820,0x3c0,0x3c0,0x820,0x1,0x5001},
   {0x5001,0x1,0x820,0x3c0,0x3c0,0x820,0x4000,0x4005},
   {0x1400,0x1,0x201,0x3e0,0xbc0,0x4080,0x4000,0x14},
   {0x500,0x0,0x81,0xbc1,0x43e0,0x4200,0x0,0x50},
   {0x140,0x0,0x820,0x43c1,0x43c1,0x820,0x0,0x140},
   {0x50,0x0,0x4200,0x43e0,0xbc1,0x81,0x0,0x500},
   {0x14,0x4000,0x4080,0xbc0,0x3e0,0x201,0x1,0x1400},
   {0x4005,0x4000,0x820,0x3c0,0x3c0,0x820,0x1,0x5001},
   {0x5001,0x1,0x820,0x3c0,0x3c0,0x820,0x4000,0x4005},
   {0x1400,0x1,0x201,0x3e0,0xbc0,0x4080,0x4000,0x14},
   {0x500,0x0,0x81,0xbc1,0x43e0,0x4200,0x0,0x50},
};

//volatile stuff
volatile unsigned char row = 0, col = 0, speed = 3;

//the actually loaded frame in the RAM
volatile unsigned int frametemp[8];

//timer overflow for proper loading of lines 
SIGNAL( TIMER1_COMPA_vect )
{
   //if we reached the bottom, send out the next high impulse to the vertical register
   if( ++row == 8 )
   {
      sbi( MATRIX_PORT, VERT_DATA );
      row = 0;
   }
   //step data into the line
   for( col = 0; col < 16; col++ )
   {
      //we are masking with the col variable, which is growing, so the last masked bit will be the first led in the row
      //we have to invert the information, because we controlling cathodes now
      if( frametemp[row] & 1<<(col) ) cbi( MATRIX_PORT, HOR_DATA );
      else sbi( MATRIX_PORT, HOR_DATA);

      //step it in with the clock pin
      cbi( MATRIX_PORT, HOR_CLK ); 
      sbi( MATRIX_PORT, HOR_CLK );
   }
   //now step down the line control to see the line until the timer's lust overflow
   sbi( MATRIX_PORT, VERT_CLK );
   cbi( MATRIX_PORT, VERT_CLK );
   //this is for the case if we reached the bottom (see line 50.)
   cbi( MATRIX_PORT, VERT_DATA );
}

int main(void)
{
   //the index of the current frame
   unsigned int actual_frame = 0;
   //the amount of the frames we have
   unsigned int last_frame = NUM_ELEM(framepgm);

   //set the data directions
   sbi( MATRIX_DDR, VERT_CLK);
   sbi( MATRIX_DDR, VERT_DATA);
   sbi( MATRIX_DDR, HOR_DATA);
   sbi( MATRIX_DDR, HOR_CLK);

   //the options for: SIGNAL( TIMER1_COMPA_vect )
   TCCR1B = (1 << WGM12) | 1;
   OCR1A = 35000;
   TIMSK |= 1 << OCIE1A;
   //enabling the interrupts
   sei();

   //main loop
   while( 1 )
   {
      //increasing the actual frame, and if we are at the last, go back to the first
      if( ++actual_frame == last_frame ) actual_frame = 0;
      //get the frame
      loadframe( actual_frame );
      //delaying until we want to change the frame (this is not affects the interrupt if the timer, so the drawing is continous)
      _delay_ms( (10 - speed )* 15 );
   }
}

//getting the frame from the program memory
void loadframe( unsigned char nextframe)
{
   for(unsigned int i=0;i<8;i++) frametemp[i]=pgm_read_word(&(framepgm[nextframe][i]));
}
