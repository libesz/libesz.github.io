/************************************************************
* Project: IR remote switch                                 *
*                                                           *
* $Id:: usart.h 33 2010-03-09 21:25:35Z libesz             $*
*************************************************************/

#ifndef USART_H
#define USART_H

#define PROMPT "ir> "
#define USART_BAUDRATE 38400
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)
#define usart_puts_P(__s) usart_puts_p(P(__s))
#define P(s) ({static const char c[] __attribute__ ((progmem)) = s;c;})


extern void usart_init( void );

extern void usart_putc( unsigned char c );

extern void usart_puts ( unsigned char *s);

extern void usart_nl( void );

extern void usart_puts_p(const char *progmem_s );

extern void usart_puti( const int val );

void usart_put_prompt( void );

void usart_bad_commend( void );

#endif // UART_H 
