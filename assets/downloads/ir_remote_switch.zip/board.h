/************************************************************
* Project: IR remote switch                                 *
*                                                           *
* $Id:: board.h 33 2010-03-09 21:25:35Z libesz             $*
*************************************************************/

#ifndef BOARD_H
#define DOARD_H

//define eeprom addresses
#define FIRST_BTN_ADDR 2
#define CONFIG_VALID_ADDR 0

#define LED_DDR      DDRD
#define LED_PORT     PORTD
#define LED_PIN_NUM  4

#define LEARN_SW_PORT PORTB
#define LEARN_SW_PIN PINB
#define LEARN_SW_PIN_NUM 4

#define OUT_PORT_B 32
#define OUT_PORT_C 64
#define OUT_PORT_D 128

volatile unsigned char output_config[8]=
   {
      OUT_PORT_C | 0,
      OUT_PORT_C | 1,
      OUT_PORT_C | 2,
      OUT_PORT_C | 3,
      OUT_PORT_C | 4,
      OUT_PORT_C | 5,
      OUT_PORT_B | 0,
      OUT_PORT_B | 1,
   };

#endif
