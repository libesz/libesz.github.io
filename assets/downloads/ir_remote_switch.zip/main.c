/************************************************************
* Project: IR remote switch                                 *
*                                                           *
* $Id:: main.c 33 2010-03-09 21:25:35Z libesz              $*
*************************************************************/

#define WITHUSART

#ifdef WITHUSART
//#define DEBUG
#endif

#include "board.h"

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include <stdlib.h>
#include <string.h>
#include <avr/eeprom.h>
#include <avr/sfr_defs.h>

#ifdef WITHUSART
#include "usart.h"

volatile unsigned char command[20], command_tok[20], *decoded_command, char1, char2, command_i=0;

#endif

// global defines for system
#define NORMAL   1
#define LEARNING 2
#define SLEEP_BUTTON_PRESSED 4

#define BLINK_ONE  8

#define LEARNING_SAMPLES 2
#define MAX_LEARNING_TRY 10

// global variables for the system
volatile unsigned char system_status = NORMAL;
volatile unsigned char learning_number = 0;

// global variables for recieving IR data
volatile unsigned long int recieved_data=0;
volatile unsigned int measured_time=0, timer2_i=0;
volatile unsigned char rec_status=0, recieved=0, recieved_bits=0, startbit_time=0, sleep_timers[8];


#ifdef DEBUG
void send_rec_dump( void );
#endif

// global definitions for recieving IR data
#define IDLE 0
#define SBIT 1
#define DATA 2

#define MAXTIME 10000
#define MINTIME 10
#define STARTBIT_MULTIPLIER 12
//#define MATCH_BEGIN

void init1( void );
void init2( void );
void one_output_on( unsigned char );
void one_output_off( unsigned char );
unsigned char get_one_output_state( unsigned char );
void all_output_off( void );
void send_rec_dump( void );
void start_learning( void );
void set_sleep( unsigned char, unsigned char );

#ifdef WITHUSART
ISR(USART_RXC_vect)
{
   unsigned char usart_rec_byte=0, command_success = 1;
	usart_rec_byte = UDR; // �rkezett b�jt let�rol�sa
   if(usart_rec_byte==0x64) return;
	if(usart_rec_byte=='\r') // kocsivissza karakter, vagyis az ENTER a parancs v�g�n
	{
      usart_nl();

      command[command_i]=0; // parancs karaktersorozat lez�r�sa
      
      //strtok_r( command, " ", command_tok );
      decoded_command = strtok_r( command, " ", command_tok );

      char1 = atoi( strtok_r( NULL, " ", command_tok ));
      char2 = atoi( strtok_r( NULL, " ", command_tok ));

#ifdef DEBUG
      usart_puti(command_i);
      usart_putc(' ');
      usart_puts(decoded_command);
      usart_nl();

      usart_puti(char1);
      usart_putc(' ');
      usart_puti(char2);
      usart_putc(' ');
#endif
      
      if( !strcmp( decoded_command, "on" ) )
      {
         if( ( char1 > 0 ) && ( char1 < 9 ) )
         {
            one_output_on( char1 - 1 );
         }
         else command_success = 0;
      }
      else if( !strcmp( decoded_command, "off" ) )
      {
         if( ( char1 > 0 ) && ( char1 < 9 ) )
         {
            one_output_off( char1 - 1 );
         }
         else command_success = 0;
      }
      else if( !strcmp( decoded_command, "sleep" ) )
      {
         set_sleep( char1-1, char2);
      }
#ifdef DEBUG
      else if( !strcmp( decoded_command, "dump" ) )
      {
         usart_nl();
         usart_puts_P(" +++ dumping learned data:");
         usart_nl();
         for(unsigned char i=0; i<9; i++)
         {
            usart_puti(i);
            usart_putc(' ');
            for( unsigned char j=0; j<4 ; j++ )
            {
               unsigned char temp_data = eeprom_read_byte((unsigned char *) ( FIRST_BTN_ADDR + (i * 4) + j ) );
               for( unsigned char k=8; k>0 ; k-- )
               {
                  if(temp_data & ( 1 << (k-1) )) usart_putc('1');
                  else usart_putc('0');
               }
            }
            usart_nl();
         }
      }
#endif
      else if( !strcmp( decoded_command, "learn" ) )
      {
         start_learning();
      }
      else if( command_i )
      {
         usart_puts_P(" +++    ___help___");
         usart_nl();
         usart_puts_P(" +++ available commands:");
         usart_nl();
         usart_puts_P(" +++ on <output number> | turn on one output");
         usart_nl();
         usart_puts_P(" +++ off <output number>");
         usart_nl();
         usart_puts_P(" +++ sleep <output number> <minutes> | set on one output for a given time");
         usart_nl();
         usart_puts_P(" +++ learn | to trigger learning");
         usart_nl();
#ifdef DEBUG
         usart_puts_P(" +++ dump | to dump out the stored button data");
         usart_nl();
#endif
         }
      
      if( !command_success ) usart_bad_commend();
      if( system_status == NORMAL ) usart_put_prompt();
  		command_i=0;
   }
   else if( usart_rec_byte != 127 )
   {
      if(command_i<20)
      {
         usart_putc(usart_rec_byte);
         command[command_i]=usart_rec_byte;
         command_i++;
      }
   }
   else if( command_i )
   {
      usart_putc(usart_rec_byte);
      command_i--;
      command[command_i]=0;
   }
}

#endif

// timer overflow for more proper time measure
ISR (TIMER0_OVF_vect)
{
   if( measured_time < MAXTIME ) measured_time++; 
   else if( recieved_bits )
   {
      recieved = 1;
      rec_status = IDLE;
   }
}

ISR (TIMER2_OVF_vect)
{
   if( ++timer2_i == 3600)
   {
      timer2_i = 0;
      for( unsigned char i=0; i<8; i++ )
      {
         if( sleep_timers[i] )
         {
            if( !(--sleep_timers[i]) )
            {
               one_output_off( i );
            }
         }
      }
   }
   if( !(timer2_i % 10) )
   {
      if( system_status & BLINK_ONE )
      {
         if( LED_PORT & 1<<(LED_PIN_NUM) )
         {
            LED_PORT &= ~(1<<(LED_PIN_NUM));
            system_status &= ~(BLINK_ONE);
         }
         else
         {
            LED_PORT |= 1<<(LED_PIN_NUM);
         }
      }
      else if( system_status & SLEEP_BUTTON_PRESSED )
      {
         if( LED_PORT & 1<<(LED_PIN_NUM) )
         {
            LED_PORT &= ~(1<<(LED_PIN_NUM));
         }
         else
         {
            LED_PORT |= 1<<(LED_PIN_NUM);
         }
      }
   }
}

// interrupt pin to got the data
ISR (INT0_vect)
{
   cli();
   if( !recieved )
   {
      if(measured_time < MINTIME )
      {
         startbit_time=0;
         recieved_data=0;
         recieved_bits=0;
         rec_status=IDLE;
         measured_time=0;
      }
      else
      {
         switch(rec_status)
         {
            case IDLE:
               if( measured_time == MAXTIME )
               {
                  recieved_data=0;
                  measured_time=0;
                  rec_status=SBIT;
               }
               break;

            case SBIT:
               startbit_time = measured_time/STARTBIT_MULTIPLIER;
               recieved_bits=0;
               measured_time=0;
               rec_status=DATA;
               break;

            case DATA:
               //usart_puti(recieved_bits);

               if( (measured_time < ( 3 * startbit_time )) 
#ifdef MATCH_BEGIN
                     && (recieved_bits < 31)
#endif                 
                 )
               {
                  recieved_data<<=1;
                  //decide that if data was 0 or 1 bit, based on the ratio of startbit and the new data's time
                  if( measured_time / (startbit_time+10) ) recieved_data++;
                  measured_time=0;
                  recieved_bits++;
               }
               else
               {
                  //recieved_data=0b11111111111111111111111111111111;
                  if( recieved_bits )recieved = 1;
                  rec_status = IDLE;
               }
               break;
         }
      }
   }
   sei();
}

int main( void )
{
   unsigned long int learning_buffer[LEARNING_SAMPLES]; //to collect the samples during learning
   unsigned char learning_array_index = 0; // for indexing the learning_buffer array
   unsigned char learning_counter = 0; // recieved samples
   unsigned char found = 0;

   init1();
   sei();
#ifdef WITHUSART
   usart_nl();
   usart_puts_P("___IR Remote Switch v0.9 starting up___");
   usart_nl();
#endif

   init2();
   //usart_put_prompt();

   while(1)
   {
      if( recieved )
      {
         cli();
#ifdef DEBUG
         send_rec_dump();
#endif
         switch( system_status & 3 )
         {
            //find out which button was pressed
            case NORMAL:
               found = 0;
               for( unsigned char i=0; i<9; i++ )
               {
                  // temp_li for compare when readed from eeprom
                  unsigned long long int temp_li=0;

                  // reading the four bytes and put together
                  for( unsigned char j=0; j<4 ; j++ )
                  {
                     temp_li <<= 8;
                     temp_li += eeprom_read_byte( (unsigned char *) ( FIRST_BTN_ADDR + (i * 4) + j ) );
                  }
                  // if it matches
                  if( temp_li == recieved_data )
                  {
                     found = 1;
                     
                     if( i != 8 )
                     {
                        if( system_status & SLEEP_BUTTON_PRESSED )
                        {
                           set_sleep( i, 30);
                           system_status &= ~(SLEEP_BUTTON_PRESSED);
                        }
                        else if( get_one_output_state(i) ) one_output_off( i );
                        else one_output_on( i );
                        system_status |= BLINK_ONE;
                        break;
                     }
                     else
                     {
                        if( system_status & SLEEP_BUTTON_PRESSED )
                        {
                           system_status &= ~(SLEEP_BUTTON_PRESSED);
                           LED_PORT &= ~(1<<(LED_PIN_NUM));
#ifdef WITHUSART
                           usart_nl();
                           usart_puts_P(" +++ sleep button pressed again");
                           usart_nl();
#endif
                        }
                        else
                        {
                           system_status |= SLEEP_BUTTON_PRESSED;
#ifdef WITHUSART
                           usart_nl();
                           usart_puts_P(" +++ sleep button pressed");
                           usart_nl();
#endif
                        }
                     }
                  }
               }
               // if not
#ifdef WITHUSART
               if( !found )
               {
                  usart_puts_P(" +++ not found");
                  usart_nl();
               }
#endif
               break;

            case LEARNING:
               // storing the recieved data in the array
               learning_buffer[learning_array_index] = recieved_data;
               // rounding the index
               if( ++learning_array_index == LEARNING_SAMPLES ) learning_array_index = 0;
#ifdef WITHUSART
               usart_putc('.');
#endif
               // didn't got enough sample from the same...
               if( ++learning_counter > MAX_LEARNING_TRY )
               {
                  learning_array_index = 0;
                  learning_counter = 0;
                  system_status = NORMAL;
#ifdef WITHUSART
                  usart_puts_P(" --- learning failed");
                  usart_nl();
#endif
                  all_output_off();
               }
               else if( learning_counter >= LEARNING_SAMPLES )
               {
                  // check the collected samples, if we have more than LEARNING_SAMPLES
                  unsigned char valid = 1;
                  for( unsigned char i=1; i<LEARNING_SAMPLES ; i++ )
                  {
                     if( learning_buffer[0] != learning_buffer[i] ) valid = 0;
                  }
                  if( valid )
                  {
#ifdef WITHUSART
                     usart_nl();
                     usart_puts_P(" +++ learning ok");
                     usart_nl();
#endif
                     learning_counter = 0;
                     // store the learned button
                     for( unsigned char i=0; i<4 ; i++ )
                     {
                        eeprom_write_byte((unsigned char *) ( FIRST_BTN_ADDR + (learning_number * 4) + (3 - i) ), recieved_data & 255 );
                        recieved_data >>= 8;
                     }
                     // temp... learn more than one button at once

                     if( ++learning_number == 9)
                     {
                        system_status = NORMAL;
                        all_output_off();
                        LED_PORT &= ~(1<<(LED_PIN_NUM));
                        learning_number = 0;
                     }
                     else
                     {
                        //shut down the last output
                        one_output_off( learning_number - 1 );
                        //indicate the next output while learning 1-8 buttons
                        one_output_on( learning_number );

#ifdef WITHUSART
                        usart_puts_P(" +++ learning ");
#endif
                        
                        if( learning_number != 8 )
                        {
#ifdef WITHUSART
                           usart_puti( learning_number + 1 );
#endif
                        }
                        else
                        {
#ifdef WITHUSART
                           usart_puts_P("sleep button");
#endif
                           //indicate the learning of the sleep button with the feedback led
                           LED_PORT |= 1<<(LED_PIN_NUM);
                        }
                     }
                  }
               }
               break;
         }
         recieved_data=0;
         recieved_bits=0;
         recieved=0;
         measured_time=0;

         sei();
      }
      //if button pressed
      if( !(LEARN_SW_PIN & 1<<LEARN_SW_PIN_NUM) && (system_status == NORMAL) ) start_learning();
   }
}


void init1( void )
{
   //selecting port directions for output
   for(unsigned char i=0; i<8; i++)
   {
      switch( output_config[i] & ( OUT_PORT_B | OUT_PORT_C | OUT_PORT_D ) )
      {
         case OUT_PORT_B: DDRB |= 1<<(output_config[i] & 7 ); break;
         case OUT_PORT_C: DDRC |= 1<<(output_config[i] & 7 ); break;
         case OUT_PORT_D: DDRD |= 1<<(output_config[i] & 7 ); break;
      }
   }

   //external learning button
   LEARN_SW_PORT |= 1<<LEARN_SW_PIN_NUM;

   LED_DDR |= 1<<LED_PIN_NUM;
   //timer init
   TCCR0  =0b00000001;
   TIMSK |= 1<<TOIE0; //timer 0 overflow bekapcsolva
   
   TCCR2  =0b00000111;
   TIMSK |= 1<<TOIE2; //timer 2 overflow bekapcsolva

#ifdef WITHUSART
   usart_init();
#endif
   GIMSK |= (1<<INT0);
   MCUCR |= ((1<<ISC01) | (0<<ISC00));
}

void init2( void )
{
   if( 0x55 != eeprom_read_byte((unsigned char *) CONFIG_VALID_ADDR ))
   {
#ifdef WITHUSART
      usart_puts_P(" +++ first run, making config... ");
#endif
      eeprom_write_byte((unsigned char *) CONFIG_VALID_ADDR, 0x55 );
#ifdef WITHUSART
      usart_puts_P("done.");
      usart_nl();
#endif
   }
}

void one_output_on( unsigned char output )
{
#ifdef WITHUSART
   usart_puts_P(" +++ on: ");
   usart_putc( output + 49 );
   usart_nl();
#endif
   switch( output_config[output] & ( OUT_PORT_B | OUT_PORT_C | OUT_PORT_D ) )
   {
      case OUT_PORT_B: PORTB |= 1<<(output_config[output] & 7 ); break;
      case OUT_PORT_C: PORTC |= 1<<(output_config[output] & 7 ); break;
      case OUT_PORT_D: PORTD |= 1<<(output_config[output] & 7 ); break;
   }
}

void one_output_off( unsigned char output )
{
#ifdef WITHUSART
   usart_puts_P(" +++ off: ");
   usart_putc( output + 49 );
   usart_nl();
#endif

   switch( output_config[output] & ( OUT_PORT_B | OUT_PORT_C | OUT_PORT_D ) )
   {
      case OUT_PORT_B: PORTB &= ~(1<<(output_config[output] & 7 )); break;
      case OUT_PORT_C: PORTC &= ~(1<<(output_config[output] & 7 )); break;
      case OUT_PORT_D: PORTD &= ~(1<<(output_config[output] & 7 )); break;
   }
   sleep_timers[ output ] = 0;
}

unsigned char get_one_output_state( unsigned char output )
{
   unsigned char state = 0;
   
   if( (output_config[output] & OUT_PORT_B ) )
   {
      if( PORTB & 1<<(output_config[output] & 7 ) )
      state = 1;
   }
   else if( (output_config[output] & OUT_PORT_C ) )
   {
      if( PORTC & 1<<(output_config[output] & 7 ) )
      state = 1;
   }
   else if( (output_config[output] & OUT_PORT_D ) )
   {
      if( PORTD & 1<<(output_config[output] & 7 ))
      state = 1;
   }
   return state;
}

void all_output_off( void )
{
   for(unsigned char i=0; i<8; i++)
   {
      switch( output_config[i] & ( OUT_PORT_B | OUT_PORT_C | OUT_PORT_D ) )
      {
         case OUT_PORT_B: PORTB &= ~(1<<(output_config[i] & 7 )); break;
         case OUT_PORT_C: PORTC &= ~(1<<(output_config[i] & 7 )); break;
         case OUT_PORT_D: PORTD &= ~(1<<(output_config[i] & 7 )); break;
      }
   }
#ifdef WITHUSART
   usart_puts_P(" +++ all outputs off");
   usart_nl();
#endif
}

#ifdef DEBUG
void send_rec_dump( void )
{

//this function sends a bitdump
   usart_nl();
   usart_puts_P(" +++ recieved: ");
   for(unsigned char i=32; i>0; i--)
   {
      if( recieved_data & ((unsigned long int)1<<(i-1)) ) usart_putc('1');
      else usart_putc('0');
      //recieved_data >>= 1;
   }
   usart_nl();
   //recieved_bits = 0;
   //recieved = 0;
   //recieved_data = 0;
   //measured_time = 0;
}
#endif

void start_learning( void )
{
   //shut down all outputs
   all_output_off();
   //switch on the first to indicate learning
   one_output_on( 0 );
   
#ifdef WITHUSART
   usart_puts_P(" +++ learning 1");
#endif
   //switch status
   system_status = LEARNING;
}

void set_sleep( unsigned char output, unsigned char min)
{
   sleep_timers[ output ] = min;
   one_output_on( output );
#ifdef WITHUSART
   usart_puts_P( " +++ sleep for output " );
   usart_puti( output + 1 );
   usart_puts_P( ": " );
   usart_puti( min );
   usart_puts_P( " min" );
   usart_nl();
#endif
}
