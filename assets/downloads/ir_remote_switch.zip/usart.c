/************************************************************
* Project: IR remote switch                                 *
*                                                           *
* $Id:: usart.c 33 2010-03-09 21:25:35Z libesz             $*
*************************************************************/


#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include "usart.h"


void usart_init( void )
{
   UCSRB |= (1 << RXEN) | (1 << TXEN);
   UCSRC |= (1 << URSEL) | (1 << UCSZ0) | (1 << UCSZ1);

   UBRRL = BAUD_PRESCALE;
   UBRRH = (BAUD_PRESCALE >> 8);
   UCSRB |= (1 << RXCIE);
}

void usart_putc( unsigned char c )
{
      while ((UCSRA & (1 << UDRE)) == 0);
      UDR = c;
}

void usart_puts ( unsigned char *s)
{
   while (*s)
   {
      usart_putc(*s);
      s++;
   }
}

void usart_nl( void )
{
   usart_puts_P("\r\n");
}

void usart_puts_p(const char *progmem_s )
{
    register char c;
    
    while ( (c = pgm_read_byte(progmem_s++)) ) 
      usart_putc(c);

}

void usart_puti( const int val )
{
    char buffer[sizeof(int)*8+1];
    
    usart_puts( itoa(val, buffer, 10) );

}

void usart_put_prompt( void )
{
   usart_puts_P(PROMPT);
}

void usart_bad_commend( void )
{
   usart_puts_P(" --- Bad command!");
   usart_nl();
}
